﻿using UnityEngine;
using System.Collections;

public class AfficheVieIdole : MonoBehaviour {

	[SerializeField]
	public GameObject _text;

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		
	}

}
